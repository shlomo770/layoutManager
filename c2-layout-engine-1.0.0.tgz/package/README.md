# @c2/layout-engine

An enterprise-grade, **metadata-driven** C2 (Command & Control) dynamic layout engine for GIS / 3D map applications. The host developer gets **absolute control** over region placement, sizing, item flow, theming, and mode switching from a single serializable **Manifest** — without ever touching the engine core.

> **Two entry points, one package:**
>
> | Import | Best for |
> | --- | --- |
> | `@c2/layout-engine` | **Dynamic engine** — map base layer + transparent overlay, multi-mode switching, memoized for live state changes (documented below). |
> | `@c2/layout-engine/shell` | **Static App Shell** — a lean, zero-runtime 5-region (`top`/`bottom`/`left`/`right`/`center`) dashboard scaffold read once at boot. See [Static App Shell](#static-app-shell-c2layout-engineshell). |

- **Two-layer Z stack** — a fullscreen map viewport (Layer 0) under a transparent `100vw × 100vh` 3×3 CSS Grid overlay (Layer 1).
- **Pointer-through by design** — the grid parent is `pointer-events: none`; only active regions capture input, so map pan/zoom/click pass straight through the transparent center.
- **Five configurable regions** — `top`, `bottom`, `left`, `right`, `overlay`.
- **Data-driven sizing & flow** — region `size` feeds the grid track templates; `top`/`bottom` flow horizontally, `left`/`right` vertically (overridable).
- **Self-aware fluid components** — every instance is wrapped in a `container-type: inline-size` slot and receives a `currentRegion` prop, so components rearrange themselves via `@container` queries when shifted between regions.
- **Tactical glassmorphism design system** — token-based dark UI you can fully re-skin from the manifest.
- **Zero map re-inits** — switching `activeMode` animates grid tracks only; the memoized map layer is never torn down, so no canvas tearing or flicker.

---

## Install

```bash
npm install @c2/layout-engine react react-dom
```

```ts
import { C2LayoutEngine, createRegistry } from "@c2/layout-engine";
import "@c2/layout-engine/styles.css";
```

> React 18+ is a peer dependency.

---

## Quick start

```tsx
import { useMemo } from "react";
import { C2LayoutEngine, createRegistry, type C2Manifest } from "@c2/layout-engine";
import "@c2/layout-engine/styles.css";
import { MapCanvas } from "./MapCanvas";
import { TrackList, Telemetry } from "./widgets";

const manifest: C2Manifest = {
  activeMode: "OPERATIONAL",
  theme: { accent: "#00f2fe", gap: "16px" },
  modes: {
    OPERATIONAL: {
      regions: {
        top:   { size: "72px", components: [{ id: "cmd", type: "CommandBar", grow: 1 }] },
        right: { size: "400px", components: [{ id: "tracks", type: "TrackList", grow: 1 }] },
        overlay: { chrome: false, interactive: false, components: [{ id: "hud", type: "OverlayHUD" }] },
      },
    },
  },
};

export function App() {
  const registry = useMemo(() => createRegistry({ TrackList, Telemetry }), []);
  const map = useMemo(() => <MapCanvas />, []); // memoize → never remounts on mode switch
  return <C2LayoutEngine manifest={manifest} registry={registry} map={map} />;
}
```

---

## The Manifest contract

The `C2Manifest` is the single source of truth. Everything visual or behavioral is declared here.

```ts
interface C2Manifest {
  activeMode: string;                          // which mode is live
  modes: Record<string, LayoutModeConfig>;     // all available arrangements
  theme?: Partial<C2ThemeTokens>;              // CSS-variable overrides
  transition?: TransitionConfig;               // mode-change animation
  className?: string;
}
```

### Switching layouts

Changing one property — `activeMode` — swaps the **entire** region allocation:

```ts
manifest.activeMode = "ANALYTICS"; // re-allocates every region, map untouched
```

### Regions

```ts
interface RegionConfig {
  size?: string;          // grid track: width for left/right, height for top/bottom
                          // e.g. "400px", "22vw", "minmax(280px, 24vw)"
  direction?: "row" | "column";   // override default item flow
  align?: Alignment;      // cross-axis
  justify?: Alignment;    // main-axis
  gap?: string;           // defaults to --c2-gap
  padding?: string;
  interactive?: boolean;  // capture pointer events (default true)
  chrome?: boolean;       // frosted-glass panel chrome (default true)
  className?: string;
  style?: CSSProperties;
  components: ComponentInstance[];
}
```

| Region    | Grid placement        | Default flow |
| --------- | --------------------- | ------------ |
| `top`     | full width, row 1     | `row`        |
| `bottom`  | full width, row 3     | `row`        |
| `left`    | column 1, middle row  | `column`     |
| `right`   | column 3, middle row  | `column`     |
| `overlay` | center cell           | `column`     |

`size` is read straight into the grid template — absent/empty side regions collapse to zero so the map keeps maximum usable area.

### Component instances

```ts
interface ComponentInstance {
  id: string;             // unique per region (React key + memo diffing)
  type: string;           // registry key → resolved to a React component
  props?: Record<string, unknown>;
  grow?: number;          // flex-grow weight in the region track
  basis?: string;         // flex-basis, e.g. "240px"
  visible?: boolean;      // false = mounted but hidden (keeps state)
  className?: string;
  style?: CSSProperties;
}
```

---

## Self-aware components

Every registered component receives injected props and is wrapped in a containment context:

```tsx
import type { C2ComponentProps } from "@c2/layout-engine";

function TrackList({ currentRegion, regionDirection, mode, instanceId }: C2ComponentProps) {
  const compact = regionDirection === "row"; // branch on the host region
  return <div className="c2-fluid-list">{/* … */}</div>;
}
```

Injected props:

| Prop              | Description                                         |
| ----------------- | --------------------------------------------------- |
| `currentRegion`   | the region this instance currently lives in         |
| `regionDirection` | the host region's flow (`row` \| `column`)          |
| `mode`            | the active layout mode key                          |
| `instanceId`      | the manifest instance id (stable across mode swaps) |

### Container queries (no JS measurement)

Each slot is `container-type: inline-size` with `container-name: c2-slot`. Use the provided utilities or write your own `@container` rules:

- `.c2-fluid` — stacks as a column in narrow slots, flips to a row in wide ones.
- `.c2-fluid-list` — list density tightens in narrow rails.

The flip threshold is the `--c2-wide-threshold` token (default `420px`).

---

## Theming

All visuals are CSS custom properties. Override per-manifest via `theme`, or globally in your CSS.

```ts
theme: {
  accent: "#00f2fe",
  panelBg: "rgba(10, 15, 30, 0.75)",
  panelBlur: "12px",
  panelBorder: "1px solid rgba(0, 242, 254, 0.15)",
  gap: "16px",
  statusCritical: "#ff3b5c",
  statusWarning: "#ffb020",
  statusNominal: "#16d39a",
}
```

See `C2ThemeTokens` for the full token list (each maps to a `--c2-*` variable).

---

## Performance & safety

- `C2LayoutEngine`, `RegionResolver`, and `ComponentSlot` are wrapped in `React.memo`.
- Grid templates, theme vars, region styles, and context value are derived with `useMemo`.
- The `map` element is rendered **once** at a stable tree position and never keyed by mode — so changing `activeMode` only animates the grid tracks (`grid-template-*` transition) and never re-initializes the map canvas.
- Honors `prefers-reduced-motion`.

---

## Built-in components

| Export        | Description                                          |
| ------------- | ---------------------------------------------------- |
| `Panel`       | Frosted-glass content panel with header/eyebrow.     |
| `StatusBadge` | High-contrast Critical / Warning / Nominal badge.    |

Both are usable via the registry **and** standalone inside your own components.

---

## Run the demo

```bash
npm install
npm run demo
```

A full Sentinel C2 demo with an animated radar map, two modes (Operational / Analytics), and a live "init count" overlay proving the map never re-initializes across mode switches.

## Scripts

| Script                | Action                              |
| --------------------- | ----------------------------------- |
| `npm run build`       | Build the library (ESM + CJS + dts) |
| `npm run typecheck`   | Type-check everything               |
| `npm run demo`        | Start the demo dev server           |
| `npm run demo:build`  | Production-build the demo           |

---

## Static App Shell (`@c2/layout-engine/shell`)

A separate, **zero-runtime** flavor for when you just need to scaffold a classic dashboard once at boot — no modes, no transitions, no listeners, no internal state. It draws a single `100vw × 100vh` CSS-Grid shell with five **classic** regions and a generic `center` slot.

- **5 classic regions** — `top` (header/status), `bottom` (footer/alerts), `left` (sidebar/nav), `right` (control panel), and `center` (the core application slot: map, table, video, dashboard, …).
- **Native track collapse** — omit `left` or `right` and its grid track resolves to `0px`, so `center` (the `1fr` track) automatically claims the space.
- **Data-driven tracks** — `regions.right.size: "400px"` becomes a 400px right column; `top`/`bottom` `size` becomes a row height.
- **Default flows** — `top`/`bottom` run `row`, `left`/`right`/`center` run `column` (each overridable).
- **Container isolation** — every region's component is wrapped in a `container-type: inline-size` slot (`container-name: c2region`) and receives a static `currentRegion` (+ `regionDirection`) prop.
- **Tactical glassmorphism** — overridable `--c2s-*` tokens (`accent`, `gap`, `panelPadding`, `panelBg`, `panelBlur`, …).

### Usage

```tsx
import { C2AppShell, defineLayoutConfig, type ShellComponentMap } from "@c2/layout-engine/shell";
import "@c2/layout-engine/shell/styles.css";

const registry: ShellComponentMap = {
  StatusHeader, NavRail, ControlPanel, AlertTicker,
  MapView, // the generic center component
};

const config = defineLayoutConfig({
  theme: { accent: "#00f2fe", gap: "16px", panelPadding: "16px" },
  regions: {
    top:    { size: "64px",  component: "StatusHeader" },
    left:   { size: "220px", component: "NavRail" },
    center: {                component: "MapView" },     // generic core slot
    right:  { size: "320px", component: "ControlPanel" },
    bottom: { size: "56px",  component: "AlertTicker" },
    // Omit `left`/`right` entirely → that track collapses to 0px.
  },
});

export const App = () => <C2AppShell config={config} registry={registry} />;
```

### The `C2LayoutConfig` contract

```ts
interface C2LayoutConfig {
  regions: Partial<Record<ShellRegionId, ShellRegionConfig>>; // top|bottom|left|right|center
  theme?: Partial<ShellThemeTokens>;
  className?: string;
}

interface ShellRegionConfig {
  component: string;      // registry key (the `center` slot is fully generic)
  size?: string;          // left/right → column width; top/bottom → row height
  props?: Record<string, unknown>;
  direction?: "row" | "column";   // override the default flow
  align?: ShellAlign;
  justify?: ShellAlign;
  padding?: string;
  chrome?: boolean;       // glass panel chrome (default: true for edges, false for center)
  className?: string;
  style?: CSSProperties;
}
```

### Container queries

Each region slot exposes `container-name: c2region`. Components self-adjust to their region width with no JS:

```css
@container c2region (min-width: 480px) { /* wide region → row layout */ }
@container c2region (max-width: 479px) { /* narrow region → stacked layout */ }
```

Provided utilities: `.c2s-fluid` (column → row flip), `.c2s-fluid-list` (density), `.c2s-hide-narrow`.

### Run the static-shell demo

```bash
npm run demo        # then open http://localhost:5180/shell.html
```

---

## License

MIT
